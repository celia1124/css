const mobilProduct = {
    fullNumber: '商品編號',
    name: '商品名稱',
    model: '商品型號',
    brand: '商品品牌',
    price: '商品價格',
}